package ubu.numnim.touchtest;

import android.app.Activity;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.constraint.ConstraintLayout;
import android.text.Html;
import android.view.Gravity;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;

public class Spin extends Activity {
    private Random random = new Random();
    private ImageView cupid;
    private int spinlast;
    private boolean spin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spin);
        cupid = (ImageView) findViewById(R.id.cupid);

    }


    public void Backactivity(View view) {
        final MediaPlayer mp1 = MediaPlayer.create(this, R.raw.ping);
        mp1.start();

        finish();

    }

    public void spin(View view) {
        if (!spin) {
            int spinnew = random.nextInt(30000);
            float x = cupid.getWidth() / 2;
            float y = cupid.getHeight() / 2;

            Animation rotateAnimation = new RotateAnimation(spinlast, spinnew, x, y);
            rotateAnimation.setFillAfter(true);
            rotateAnimation.setDuration(2500);
            rotateAnimation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                    spin = true;
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    spin = false;

                    showsound();

                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });

            spinlast = spinnew;
            cupid.startAnimation(rotateAnimation);
            final MediaPlayer mp = MediaPlayer.create(this, R.raw.nim);
            mp.start();


        }


    }

    private void showsound() {
        final MediaPlayer mp1 = MediaPlayer.create(this, R.raw.shoot);
        mp1.start();

        ConstraintLayout constraintLayout = (ConstraintLayout) findViewById(R.id.rm);
        final TextView textView = new TextView(this);
        ConstraintLayout.LayoutParams layoutParams = new ConstraintLayout.LayoutParams(MATCH_PARENT, 3500);

        textView.setLayoutParams(layoutParams);
        textView.setText(Html.fromHtml("<b>" + "!! YOU !!" + "</b>"));
        textView.setTextSize(50);
        textView.setTextColor(Color.parseColor("#000000"));

        textView.setGravity(Gravity.CENTER);
        constraintLayout.addView(textView);

            CountDownTimer timer = new CountDownTimer(3500, 1000) {

                @Override
                public void onTick(long millisUntilFinished) {
                }

                @Override
                public void onFinish() {
                    textView.setVisibility(View.INVISIBLE); //(or GONE)
                }
            }.start();


        }}






