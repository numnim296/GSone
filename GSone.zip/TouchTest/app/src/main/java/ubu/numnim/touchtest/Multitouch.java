package ubu.numnim.touchtest;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;


public class Multitouch extends View {


    private static final int SIZE = 130;

    private SparseArray<PointF> PointerActive;
    private Paint DrawPaint;
    private int[] colors = {Color.BLACK, Color.RED, Color.GREEN,
            Color.CYAN, Color.GRAY, Color.MAGENTA, Color.BLUE,
            Color.LTGRAY, Color.YELLOW};


    public Multitouch(Context context, AttributeSet attrs) {
        super(context, attrs);
        initView();
    }

    private void initView() {
        PointerActive = new SparseArray<PointF>();
        DrawPaint = new Paint(Paint.DITHER_FLAG);
        DrawPaint.setColor(Color.RED);
        DrawPaint.setStyle(Paint.Style.FILL_AND_STROKE);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        int pointerIndex = event.getActionIndex();
        int pointerId = event.getPointerId(pointerIndex);
        int maskedAction = event.getActionMasked();

        switch (maskedAction) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {

                PointF f = new PointF();
                f.x = event.getX(pointerIndex);
                f.y = event.getY(pointerIndex);
                PointerActive.put(pointerId, f);
                break;
            }
            case MotionEvent.ACTION_MOVE: {
                for (int size = event.getPointerCount(), i = 0; i < size; i++) {
                    PointF point = PointerActive.get(event.getPointerId(i));
                    if (point != null) {
                        point.x = event.getX(i);
                        point.y = event.getY(i);
                    }
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL: {
                PointerActive.remove(pointerId);
                break;
            }
        }
        invalidate();

        return true;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (int size = PointerActive.size(), i = 0; i < size; i++) {
            PointF point = PointerActive.valueAt(i);
            if (point != null)
                DrawPaint.setColor(colors[i % 9]);
            canvas.drawCircle(point.x, point.y, SIZE, DrawPaint);


        }

    }

}
