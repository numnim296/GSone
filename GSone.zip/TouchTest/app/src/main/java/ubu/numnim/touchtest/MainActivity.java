package ubu.numnim.touchtest;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.TextView;


public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView textView = (TextView)findViewById(R.id.textView);
        Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(50);
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        textView.startAnimation(anim);

    }

    public void exitActivity(View view) {
        finish();

    }

    public void openTouchGameActivity(View view) {
        Intent intent = new Intent(this, MainTouch.class);
        startActivity(intent);
    }

    public void openSpinGame(View view) {
        Intent intent = new Intent(this, Spin.class);
        startActivity(intent);
        final MediaPlayer mp1 = MediaPlayer.create(this,R.raw.ping);
        mp1.start();

    }
}
