package ubu.numnim.touchtest;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;

public class MainTouch extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_touch);
        final MediaPlayer mp1 = MediaPlayer.create(this,R.raw.ping);
        mp1.start();


    }

    public void Backactivity(View view) {
        final MediaPlayer mp1 = MediaPlayer.create(this,R.raw.ping);
        mp1.start();
        finish();
    }


}